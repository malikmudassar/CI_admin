<div class="container">
    <div>
        <img src="http://www.empire-computers.co.uk/gfx/websites_banner.jpg" />
    </div>
    <div >
        <p>
        <h2>Hi! <?php echo $user['name']?>;  </h2>
        </p>
    </div>
    <div class="col-lg-12" style="border-radius: 10px; background-color: #f5f5f5; padding: 15px;">

        <p style="color: #000">
        <h3>Congratulations Your Password has been Changed</h3>
        <hr>
        <h4>Regards</h4>
        <p><strong>Webmaster</strong><br>Smart BABA</p>
    </div>
</div>