<div class="layout-footer">
    <div class="layout-footer-body">
        <small class="version">Version 1.0.0</small>
        <small class="copyright">2016 &copy; ERP By <a href="http://smartbaba.ae/">SmartBABA</a></small>
    </div>
</div>
</div>

<script src="<?php echo base_url()?>assets/js/vendor.min.js"></script>
<script src="<?php echo base_url()?>assets/js/elephant.min.js"></script>
<script src="<?php echo base_url()?>assets/js/application.min.js"></script>
<script src="<?php echo base_url()?>assets/js/demo.min.js"></script>

</body>

<!-- Mirrored from demo.naksoid.com/elephant/flaming-red/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 03 Nov 2016 14:01:15 GMT -->
</html>
<script>
    /*var time = new Date().getTime();
    $(document.body).bind("mousemove keypress", function(e) {
        time = new Date().getTime();
    });

    function refresh() {
        if(new Date().getTime() - time >= 60000)
            window.location.reload(true);
        else
            setTimeout(refresh, 10000);
    }

    setTimeout(refresh, 10000);*/
</script>